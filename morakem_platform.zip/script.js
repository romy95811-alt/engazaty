(() => {
"use strict";

/* =========================
   Local database
========================= */
const DB_KEY = "morakem_db_v2";
const SESSION_KEY = "morakem_current_user_v2";

const teachers = [
  {id:"arabic", name:"مستر محمد صلاح", subject:"العربي", count:25, days:["السبت","الثلاثاء"], detail:"شرح السبت • واجب الثلاثاء", icon:"📚"},
  {id:"english", name:"مستر محمود رضوان (انجلشاوي)", subject:"English", count:32, days:["الأحد","الأربعاء"], detail:"شرح وكلمات الأحد • واجب الأربعاء", icon:"🇬🇧"},
  {id:"kamal", name:"مستر كمال المراكبي", subject:"المادة", count:27, days:["الاثنين","الخميس"], detail:"شرح • متابعة وواجب", icon:"🎓"},
  {id:"history", name:"مستر أحمد عادل", subject:"التاريخ", count:30, days:["السبت","الثلاثاء"], detail:"شرح • واجب", icon:"🏛️"}
];

const dayNames = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];

const translations = {
  ar:{
    appName:"المراكم",platformSubtitle:"متابعة المحاضرات",authSubtitle:"رتّب محاضراتك، تابع إنجازك، واقفل المتراكم خطوة بخطوة.",
    login:"تسجيل الدخول",register:"إنشاء حساب",emailOrPhone:"رقم الهاتف أو البريد الإلكتروني",password:"كلمة المرور",
    fullName:"الاسم بالكامل",phoneTip:"يفضل التسجيل برقم الهاتف لسهولة استرجاع الحساب.",confirmPassword:"تأكيد كلمة المرور",
    academicYear:"السنة الدراسية",semester:"الترم",track:"المسار",createAccount:"إنشاء الحساب",demoNote:"نسخة تجريبية مجانية: البيانات محفوظة على هذا الجهاز فقط.",
    dashboard:"الرئيسية",lectures:"المحاضرات",schedule:"الجدول",focus:"جلسة التركيز",achievements:"الإنجازات",religious:"أعمالي الدينية",statistics:"الإحصائيات",
    settings:"الإعدادات",logout:"تسجيل الخروج",welcome:"أهلاً بيك",activityStatus:"حالة النشاط",points:"النقاط",completed:"منجز",remaining:"متبقي",lectureWord:"محاضرة",progress:"التقدم",
    today:"اليوم",todayTasks:"مهام اليوم",viewAll:"عرض الكل",quick:"سريع",quickActions:"اختصارات",startFocus:"ابدأ جلسة تركيز",focusHint:"ذاكر بدون تشتيت",
    trackLectures:"تابع المحاضرات",lecturesHint:"اعرف المتبقي عليك",religiousHint:"قرآن وأذكار",seeAchievements:"شوف إنجازاتك",achievementsHint:"كل خطوة محسوبة",
    teachers:"المدرسين",lectureProgress:"تقدم المحاضرات",followUp:"متابعة",allLectures:"كل المحاضرات",allTeachers:"كل المدرسين",allStatus:"الكل",remainingOnly:"المتبقي",completedOnly:"المنجز",
    weekly:"أسبوعي",scheduleTitle:"جدول نزول المحاضرات",focusRoom:"Focus Room",focusTitle:"جلسة مذاكرة وتركيز",minutes:"دقيقة",custom:"مخصص",start:"ابدأ",pause:"إيقاف مؤقت",reset:"إعادة",focusReady:"جاهز؟ ابدأ أول جلسة.",
    quran:"القرآن الكريم",quranStudy:"صوت أثناء المذاكرة",quranNote:"يمكنك وضع رابط صوت مصرح باستخدامه في الإعدادات وتشغيله أثناء جلسة المذاكرة.",
    play:"تشغيل",stop:"إيقاف",audioNote:"استخدم مصدرًا تملك حق استخدامه أو مصدرًا مرخصًا.",quranCard:"قراءة القرآن من مصدر موثوق.",openSource:"فتح المصدر",
    morningEvening:"أذكار الصباح والمساء",azkarText:"اجعل لك وردًا ثابتًا من الأذكار.",studyDuas:"أدعية للمذاكرة",duasText:"أدعية قصيرة قبل وأثناء المذاكرة.",
    otherActs:"أعمال أخرى",otherActsText:"صدقة، بر الوالدين، صلاة وذكر.",show:"عرض",prayerTimes:"الصلاة",prayerMessages:"رسائل مواقيت الصلاة",
    spiritual:"روحانيات",religiousTitle:"أعمالي الدينية",numbers:"أرقامك",statisticsTitle:"الإحصائيات",overallProgress:"التقدم العام",completedLectures:"المحاضرات المنجزة",yourPoints:"نقاطك",outOf:"من 20,000",
    activity:"نشاط",activityDetails:"تفاصيل النشاط",language:"اللغة",sound:"الأصوات",quranAudioUrl:"رابط صوت القرآن",changeAvatar:"تغيير الصورة",save:"حفظ التغييرات",
    notifications:"الإشعارات",clear:"مسح",activityNow:"نشط الآن",noNotifications:"لا توجد إشعارات حالياً.",noTasks:"لا توجد مهام اليوم.",lecture:"محاضرة",complete:"تم الإنجاز",undo:"إلغاء الإنجاز",
    dueToday:"مطلوبة اليوم",available:"متاحة اليوم",pointsEarned:"نقطة",remainingLabel:"متبقي",completedLabel:"منجز",lastActive:"آخر نشاط",account:"الحساب"
  },
  en:{
    appName:"Morakem",platformSubtitle:"Lecture Tracker",authSubtitle:"Organize your lectures, track progress, and clear your backlog step by step.",
    login:"Log in",register:"Create account",emailOrPhone:"Phone or email",password:"Password",fullName:"Full name",
    phoneTip:"Phone registration is recommended for easier account recovery.",confirmPassword:"Confirm password",academicYear:"Academic year",
    semester:"Semester",track:"Track",createAccount:"Create account",demoNote:"Free demo: data is stored on this device only.",
    dashboard:"Dashboard",lectures:"Lectures",schedule:"Schedule",focus:"Focus Room",achievements:"Achievements",religious:"My Deeds",statistics:"Statistics",
    settings:"Settings",logout:"Log out",welcome:"Welcome",activityStatus:"Activity status",points:"Points",completed:"Completed",remaining:"Remaining",
    lectureWord:"lectures",progress:"Progress",today:"Today",todayTasks:"Today's tasks",viewAll:"View all",quick:"Quick",quickActions:"Shortcuts",
    startFocus:"Start focus",focusHint:"Study without distraction",trackLectures:"Track lectures",lecturesHint:"See what's left",religiousHint:"Quran & adhkar",
    seeAchievements:"See achievements",achievementsHint:"Every step counts",teachers:"Teachers",lectureProgress:"Lecture progress",followUp:"Tracking",
    allLectures:"All lectures",allTeachers:"All teachers",allStatus:"All",remainingOnly:"Remaining",completedOnly:"Completed",weekly:"Weekly",
    scheduleTitle:"Lecture release schedule",focusRoom:"Focus Room",focusTitle:"Study & focus session",minutes:"minutes",custom:"Custom",start:"Start",
    pause:"Pause",reset:"Reset",focusReady:"Ready? Start your first session.",quran:"Quran",quranStudy:"Audio while studying",
    quranNote:"Add an authorized audio URL in settings and play it during your study session.",play:"Play",stop:"Stop",
    audioNote:"Use audio you have permission to use or a properly licensed source.",quranCard:"Read Quran from a trusted source.",openSource:"Open source",
    morningEvening:"Morning & evening adhkar",azkarText:"Keep a regular daily adhkar routine.",studyDuas:"Study duas",duasText:"Short duas before and during study.",
    otherActs:"Other deeds",otherActsText:"Charity, kindness to parents, prayer and remembrance.",show:"View",prayerTimes:"Prayer",prayerMessages:"Prayer-time messages",
    spiritual:"Spiritual",religiousTitle:"My Deeds",numbers:"Your numbers",statisticsTitle:"Statistics",overallProgress:"Overall progress",
    completedLectures:"Completed lectures",yourPoints:"Your points",outOf:"out of 20,000",activity:"Activity",activityDetails:"Activity details",
    language:"Language",sound:"Sounds",quranAudioUrl:"Quran audio URL",changeAvatar:"Change image",save:"Save changes",notifications:"Notifications",
    clear:"Clear",activityNow:"Active now",noNotifications:"No notifications yet.",noTasks:"No tasks today.",lecture:"Lecture",complete:"Completed",
    undo:"Undo completion",dueToday:"Due today",available:"Available today",pointsEarned:"points",remainingLabel:"remaining",completedLabel:"completed",
    lastActive:"Last active",account:"Account"
  }
};

let db = loadDB();
let currentUserId = localStorage.getItem(SESSION_KEY);
let currentUser = currentUserId ? db.users.find(u=>u.id===currentUserId) : null;
let timer = {seconds:1500,total:1500,running:false,interval:null};
let audioContext = null;

function loadDB(){
  try{
    const raw=localStorage.getItem(DB_KEY);
    if(raw) return JSON.parse(raw);
  }catch(e){}
  return {users:[]};
}
function saveDB(){ localStorage.setItem(DB_KEY, JSON.stringify(db)); }
function uid(){ return "u_"+Date.now()+"_"+Math.random().toString(36).slice(2,8); }
function defaultAvatar(name="طالب"){
  const initials = name.trim().slice(0,2) || "م";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160"><defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#5b5ce2"/><stop offset="1" stop-color="#7c3aed"/></linearGradient></defs><rect width="160" height="160" rx="42" fill="url(#g)"/><text x="80" y="98" text-anchor="middle" font-family="Arial" font-size="62" font-weight="700" fill="white">${escapeHtml(initials)}</text></svg>`;
  return "data:image/svg+xml;charset=UTF-8,"+encodeURIComponent(svg);
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function ensureUserShape(u){
  u.completed = Array.isArray(u.completed) ? u.completed : [];
  u.notifications = Array.isArray(u.notifications) ? u.notifications : [];
  u.avatar = u.avatar || defaultAvatar(u.name);
  u.settings = u.settings || {theme:"light",language:"auto",sound:"on",quranUrl:""};
  u.lastActive = u.lastActive || Date.now();
  return u;
}
db.users.forEach(ensureUserShape);
saveDB();

function getLanguage(){
  const pref=currentUser?.settings?.language || "auto";
  if(pref==="ar" || pref==="en") return pref;
  return navigator.language?.toLowerCase().startsWith("ar") ? "ar" : "en";
}
function t(key){return translations[getLanguage()][key] || translations.ar[key] || key;}
function applyLanguage(){
  const lang=getLanguage();
  document.documentElement.lang=lang;
  document.documentElement.dir=lang==="ar"?"rtl":"ltr";
  document.querySelectorAll("[data-i18n]").forEach(el=>el.textContent=t(el.dataset.i18n));
  renderAll();
}
function applyTheme(){
  document.body.classList.toggle("dark", currentUser?.settings?.theme==="dark");
  const btn=document.getElementById("themeBtn");
  if(btn) btn.textContent=currentUser?.settings?.theme==="dark"?"☀":"☾";
}
function beep(freq=520,duration=.055){
  if(currentUser?.settings?.sound==="off") return;
  try{
    audioContext ||= new (window.AudioContext||window.webkitAudioContext)();
    const o=audioContext.createOscillator(), g=audioContext.createGain();
    o.frequency.value=freq;o.type="sine";g.gain.value=.045;
    o.connect(g);g.connect(audioContext.destination);o.start();
    g.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+duration);
    o.stop(audioContext.currentTime+duration);
  }catch(e){}
}
function celebrate(){
  if(currentUser?.settings?.sound==="off") return;
  [660,880,1046].forEach((f,i)=>setTimeout(()=>beep(f,.13),i*100));
}
function toast(title,message){
  const wrap=document.getElementById("toastContainer");
  const el=document.createElement("div");el.className="toast";
  el.innerHTML=`<b>${escapeHtml(title)}</b><span>${escapeHtml(message)}</span>`;
  wrap.appendChild(el);setTimeout(()=>el.remove(),3600);
}
function markActivity(){
  if(!currentUser)return;
  currentUser.lastActive=Date.now();saveDB();
}
function activityLabel(){
  if(!currentUser)return "";
  const diff=Date.now()-currentUser.lastActive;
  if(diff<120000)return t("activityNow");
  const mins=Math.floor(diff/60000);
  if(mins<60)return `${t("lastActive")}: ${mins} ${getLanguage()==="ar"?"د":"min"}`;
  const hrs=Math.floor(mins/60);
  if(hrs<24)return `${t("lastActive")}: ${hrs} ${getLanguage()==="ar"?"س":"h"}`;
  return `${t("lastActive")}: ${Math.floor(hrs/24)} ${getLanguage()==="ar"?"ي":"d"}`;
}
function totalLectures(){return teachers.reduce((a,b)=>a+b.count,0)}
function points(){
  const total=totalLectures();
  const done=Math.min(currentUser.completed.length,total);
  return Math.min(20000,Math.round(done/total*20000));
}
function lectureId(teacher,index){return `${teacher.id}-${index}`;}
function allLectures(){
  const arr=[];
  teachers.forEach(teacher=>{
    for(let i=1;i<=teacher.count;i++){
      arr.push({id:lectureId(teacher,i),teacherId:teacher.id,teacher,number:i,title:`${teacher.subject} — ${t("lecture")} ${i}`});
    }
  });
  return arr;
}
function isCompleted(id){return currentUser.completed.includes(id)}
function getTodayTasks(){
  const day=dayNames[new Date().getDay()];
  return teachers.filter(tch=>tch.days.includes(day)).map(tch=>{
    const first=allLectures().find(l=>l.teacherId===tch.id && !isCompleted(l.id));
    return {teacher:tch,lecture:first};
  });
}
function addNotification(title,message){
  currentUser.notifications.unshift({id:uid(),title,message,time:Date.now(),read:false});
  currentUser.notifications=currentUser.notifications.slice(0,50);
  saveDB();
}
function dailyScheduleNotifications(){
  const now=new Date();
  if(now.getHours()<5)return;
  const key=now.toISOString().slice(0,10);
  if(currentUser.lastDailyNotification===key)return;
  const day=dayNames[now.getDay()];
  const today=teachers.filter(t=>t.days.includes(day));
  today.forEach(tch=>addNotification(
    getLanguage()==="ar"?`محاضرة ${tch.name}`:`${tch.name} lecture`,
    getLanguage()==="ar"?`فيه متابعة/محاضرة خاصة بـ ${tch.name} اليوم. افتح المحاضرات وابدأ.`:`There is a scheduled lecture/task for ${tch.name} today. Open lectures and start.`
  ));
  currentUser.lastDailyNotification=key;
  saveDB();
}
function updateBadge(){
  const n=currentUser?.notifications?.filter(x=>!x.read).length||0;
  const b=document.getElementById("notificationBadge");
  if(!b)return;
  b.textContent=n;b.classList.toggle("hidden",n===0);
}
function renderDashboard(){
  if(!currentUser)return;
  const done=currentUser.completed.length,total=totalLectures(),rem=Math.max(0,total-done),p=Math.round(done/total*100);
  document.getElementById("welcomeName").textContent=`${t("welcome")} ${currentUser.name.split(" ")[0]} 👋`;
  document.getElementById("topUserName").textContent=currentUser.name.split(" ")[0];
  document.getElementById("topAvatar").src=currentUser.avatar;
  document.getElementById("pointsValue").textContent=points().toLocaleString();
  document.getElementById("completedValue").textContent=done;
  document.getElementById("remainingValue").textContent=rem;
  document.getElementById("progressValue").textContent=p+"%";
  document.getElementById("activityText").textContent=activityLabel();
  const motivational = p===100 ? (getLanguage()==="ar"?"أتممت كل المحاضرات. إنجاز ممتاز 👑":"You completed all lectures. Great job 👑")
    : rem===0 ? (getLanguage()==="ar"?"خلصت المطلوب كله.":"You finished everything due.")
    : rem>total*.75 ? (getLanguage()==="ar"?"فيه تراكم. ابدأ بمحاضرة واحدة الآن بدل ما تسيبها تكبر.":"There is a backlog. Start with one lecture now.")
    : (getLanguage()==="ar"?"استمر، كل محاضرة بتقربك من هدفك.":"Keep going. Every lecture moves you forward.");
  document.getElementById("motivationText").textContent=motivational;
  renderTodayTasks();renderTeacherProgress();
}
function renderTodayTasks(){
  const box=document.getElementById("todayTasks");
  const tasks=getTodayTasks();
  if(!tasks.length){box.innerHTML=`<div class="empty-state">${t("noTasks")}</div>`;return}
  box.innerHTML=tasks.map(x=>{
    if(!x.lecture) return `<div class="task-item done"><div class="task-info"><b>${escapeHtml(x.teacher.name)}</b><span>${t("completedLabel")}</span></div><span>✓</span></div>`;
    return `<div class="task-item"><div class="task-info"><b>${escapeHtml(x.lecture.title)}</b><span>${escapeHtml(x.teacher.detail)}</span></div><button class="mini-complete" data-complete-id="${x.lecture.id}">✓</button></div>`;
  }).join("");
}
function renderTeacherProgress(){
  const box=document.getElementById("teacherProgress");
  box.innerHTML=teachers.map(tch=>{
    const done=allLectures().filter(l=>l.teacherId===tch.id&&isCompleted(l.id)).length;
    const p=Math.round(done/tch.count*100);
    return `<div class="teacher-card"><div class="teacher-top"><b>${tch.icon} ${escapeHtml(tch.name)}</b><span>${done}/${tch.count}</span></div><div class="progress-bar"><span style="width:${p}%"></span></div></div>`;
  }).join("");
}
function renderLectures(){
  const teacherId=document.getElementById("teacherFilter").value;
  const status=document.getElementById("statusFilter").value;
  let arr=allLectures().filter(l=>teacherId==="all"||l.teacherId===teacherId);
  if(status==="remaining")arr=arr.filter(l=>!isCompleted(l.id));
  if(status==="completed")arr=arr.filter(l=>isCompleted(l.id));
  const box=document.getElementById("lectureList");
  if(!arr.length){box.innerHTML=`<div class="empty-state">${t("noTasks")}</div>`;return}
  box.innerHTML=arr.map(l=>`
    <article class="lecture-card ${isCompleted(l.id)?"done":""}">
      <div class="lecture-head"><div><h3>${escapeHtml(l.teacher.icon+" "+l.title)}</h3><p>${escapeHtml(l.teacher.name)} • ${escapeHtml(l.teacher.detail)}</p></div><span class="lecture-number">#${l.number}</span></div>
      <div class="lecture-actions">
        <span class="points-tag">${Math.max(1,Math.round(20000/totalLectures()))} ${t("pointsEarned")}</span>
        <button class="complete-btn ${isCompleted(l.id)?"completed":""}" data-complete-id="${l.id}">${isCompleted(l.id)?"✓ "+t("undo"):t("complete")}</button>
      </div>
    </article>`).join("");
}
function renderSchedule(){
  const box=document.getElementById("scheduleGrid"),today=dayNames[new Date().getDay()];
  box.innerHTML=dayNames.map(day=>{
    const list=teachers.filter(t=>t.days.includes(day));
    return `<div class="day-card ${day===today?"today":""}"><h3>${day}</h3>${list.length?list.map(t=>`<div class="schedule-item"><b>${t.icon} ${escapeHtml(t.name)}</b><span>${escapeHtml(t.detail)}</span></div>`).join(""):`<span class="points-tag">—</span>`}</div>`;
  }).join("");
}
function renderAchievements(){
  const done=currentUser.completed.length;
  const items=[
    {icon:"🌱",title:getLanguage()==="ar"?"أول خطوة":"First step",desc:getLanguage()==="ar"?"أنجز أول محاضرة":"Complete your first lecture",ok:done>=1},
    {icon:"🔥",title:getLanguage()==="ar"?"5 محاضرات":"5 lectures",desc:getLanguage()==="ar"?"أنجز 5 محاضرات":"Complete 5 lectures",ok:done>=5},
    {icon:"⚡",title:getLanguage()==="ar"?"10 محاضرات":"10 lectures",desc:getLanguage()==="ar"?"أنجز 10 محاضرات":"Complete 10 lectures",ok:done>=10},
    {icon:"🏆",title:getLanguage()==="ar"?"25 محاضرة":"25 lectures",desc:getLanguage()==="ar"?"أنجز 25 محاضرة":"Complete 25 lectures",ok:done>=25},
    {icon:"💎",title:getLanguage()==="ar"?"50 محاضرة":"50 lectures",desc:getLanguage()==="ar"?"أنجز 50 محاضرة":"Complete 50 lectures",ok:done>=50},
    {icon:"👑",title:getLanguage()==="ar"?"كل المحاضرات":"All lectures",desc:getLanguage()==="ar"?"وصلت لـ20,000 نقطة":"Reach 20,000 points",ok:points()>=20000}
  ];
  document.getElementById("achievementGrid").innerHTML=items.map(a=>`<article class="achievement ${a.ok?"":"locked"}"><div class="achievement-icon">${a.icon}</div><h3>${a.title}</h3><p>${a.desc}</p><p>${a.ok?"✓":""}</p></article>`).join("");
}
function renderPrayers(){
  const prayers=[["الفجر","05:00"],["الظهر","12:00"],["العصر","15:30"],["المغرب","18:00"],["العشاء","19:30"]];
  document.getElementById("prayerGrid").innerHTML=prayers.map(p=>`<div class="prayer-card"><b>${p[0]}</b><span>${p[1]}</span></div>`).join("");
}
function renderStats(){
  const done=currentUser.completed.length,total=totalLectures(),p=Math.round(done/total*100);
  document.getElementById("statProgress").textContent=p+"%";
  document.getElementById("statProgressBar").style.width=p+"%";
  document.getElementById("statCompleted").textContent=done;
  document.getElementById("statRemaining").textContent=`${Math.max(0,total-done)} ${t("remainingLabel")}`;
  document.getElementById("statPoints").textContent=points().toLocaleString();
  document.getElementById("activityDetails").innerHTML=[
    [t("activityStatus"),activityLabel()],
    [t("completed"),done+" / "+total],
    [t("points"),points().toLocaleString()+" / 20,000"]
  ].map(x=>`<div><span>${escapeHtml(x[0])}</span><b>${escapeHtml(x[1])}</b></div>`).join("");
}
function renderNotifications(){
  const box=document.getElementById("notificationsList");
  const arr=currentUser.notifications||[];
  if(!arr.length){box.innerHTML=`<div class="empty-state">${t("noNotifications")}</div>`;return}
  box.innerHTML=arr.map(n=>`<div class="notification-item ${n.read?"":"unread"}"><b>${escapeHtml(n.title)}</b><span>${escapeHtml(n.message)}</span><span>${new Date(n.time).toLocaleString(getLanguage()==="ar"?"ar-EG":"en-US")}</span></div>`).join("");
}
function populateTeachers(){
  const select=document.getElementById("teacherFilter");
  select.innerHTML=`<option value="all">${t("allTeachers")}</option>`+teachers.map(t=>`<option value="${t.id}">${escapeHtml(t.name)}</option>`).join("");
}
function renderSettings(){
  if(!currentUser)return;
  document.getElementById("languageSelect").value=currentUser.settings.language||"auto";
  document.getElementById("soundSelect").value=currentUser.settings.sound||"on";
  document.getElementById("quranUrlInput").value=currentUser.settings.quranUrl||"";
  document.getElementById("settingsAvatar").src=currentUser.avatar;
  document.getElementById("settingsName").textContent=currentUser.name;
  document.getElementById("settingsMeta").textContent=`${currentUser.year} • ${currentUser.track}`;
  document.getElementById("settingsCompleted").textContent=currentUser.completed.length;
  document.getElementById("settingsRemaining").textContent=totalLectures()-currentUser.completed.length;
  document.getElementById("settingsPoints").textContent=points().toLocaleString();
}
function renderProfile(){
  document.getElementById("profileAvatar").src=currentUser.avatar;
  document.getElementById("profileName").textContent=currentUser.name;
  document.getElementById("profileIdentifier").textContent=currentUser.identifier;
  document.getElementById("profileDetails").innerHTML=[
    [t("academicYear"),currentUser.year],[t("semester"),currentUser.semester==="1"?"1":"2"],
    [t("track"),currentUser.track],[t("completed"),currentUser.completed.length],[t("points"),points().toLocaleString()],
    [t("activityStatus"),activityLabel()]
  ].map(x=>`<div><span>${escapeHtml(x[0])}</span><b>${escapeHtml(x[1])}</b></div>`).join("");
}
function renderAll(){
  if(!currentUser)return;
  currentUser=ensureUserShape(currentUser);
  db.users=db.users.map(u=>u.id===currentUser.id?currentUser:u);
  saveDB();
  populateTeachers();
  renderDashboard();renderLectures();renderSchedule();renderAchievements();renderPrayers();renderStats();renderNotifications();renderSettings();renderProfile();
  updateBadge();applyTheme();
  const audio=document.getElementById("quranAudio");
  if(audio)audio.src=currentUser.settings.quranUrl||"";
}

function showSection(id){
  document.querySelectorAll(".page-section").forEach(s=>s.classList.toggle("active",s.id===id));
  document.querySelectorAll(".nav-item[data-section]").forEach(b=>b.classList.toggle("active",b.dataset.section===id));
  document.getElementById("sidebar")?.classList.remove("open");
  beep();
  window.scrollTo({top:0,behavior:"smooth"});
}
function openModal(id){document.getElementById(id).classList.remove("hidden");beep()}
function closeModal(id){document.getElementById(id).classList.add("hidden")}

function completeLecture(id){
  if(isCompleted(id)){
    currentUser.completed=currentUser.completed.filter(x=>x!==id);
    toast(t("lectures"),t("undo"));
  }else{
    currentUser.completed.push(id);
    currentUser.completed=[...new Set(currentUser.completed)];
    const l=allLectures().find(x=>x.id===id);
    addNotification(t("complete"),`${l?.title||t("lecture")} — ${points()} ${t("pointsEarned")}`);
    toast("🎉",getLanguage()==="ar"?"ممتاز! محاضرة خلصت واتحسبت في تقدمك.":"Great! Lecture completed and progress updated.");
    celebrate();
  }
  markActivity();saveDB();renderAll();
}

function setTimerMinutes(minutes){
  clearInterval(timer.interval);timer.running=false;timer.seconds=minutes*60;timer.total=timer.seconds;updateTimerUI();
  document.querySelectorAll(".timer-presets button").forEach(b=>b.classList.toggle("active",Number(b.dataset.minutes)===minutes));
}
function updateTimerUI(){
  const m=Math.floor(timer.seconds/60).toString().padStart(2,"0"),s=(timer.seconds%60).toString().padStart(2,"0");
  document.getElementById("timerDisplay").textContent=`${m}:${s}`;
  const progress=timer.total?((timer.total-timer.seconds)/timer.total)*100:0;
  document.querySelector(".timer-ring").style.setProperty("--timer-progress",`${progress}%`);
}
function startTimer(){
  if(timer.running)return;
  timer.running=true;beep(700,.08);
  timer.interval=setInterval(()=>{
    if(timer.seconds<=0){
      clearInterval(timer.interval);timer.running=false;timer.seconds=timer.total;updateTimerUI();
      celebrate();toast("🎉",getLanguage()==="ar"?"انتهت جلسة التركيز! خُد راحة قصيرة وارجع لما بعده.":"Focus session complete! Take a short break.");
      return;
    }
    timer.seconds--;updateTimerUI();markActivity();
  },1000);
}
function pauseTimer(){clearInterval(timer.interval);timer.running=false;beep(420,.06)}
function resetTimer(){clearInterval(timer.interval);timer.running=false;timer.seconds=timer.total;updateTimerUI();beep(350,.06)}

function showContent(title,body){
  document.getElementById("contentModalTitle").textContent=title;
  document.getElementById("contentModalBody").innerHTML=body;
  openModal("contentModal");
}
function setupEvents(){
  document.addEventListener("click",e=>{
    const clickable=e.target.closest("button,a");
    if(clickable && !clickable.classList.contains("complete-btn")) beep(520,.035);
  });

  document.querySelectorAll("[data-auth-tab]").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll(".auth-tab").forEach(b=>b.classList.remove("active"));btn.classList.add("active");
    const login=btn.dataset.authTab==="login";
    document.getElementById("loginForm").classList.toggle("hidden",!login);
    document.getElementById("registerForm").classList.toggle("hidden",login);
  }));

  document.getElementById("loginForm").addEventListener("submit",e=>{
    e.preventDefault();
    const identifier=document.getElementById("loginIdentifier").value.trim().toLowerCase();
    const password=document.getElementById("loginPassword").value;
    const u=db.users.find(x=>x.identifier.toLowerCase()===identifier);
    if(!u || u.password!==password){toast("تنبيه","رقم الهاتف/البريد أو كلمة المرور غير صحيحة.");return}
    currentUser=ensureUserShape(u);currentUserId=currentUser.id;localStorage.setItem(SESSION_KEY,currentUserId);markActivity();
    enterApp();toast("أهلاً بيك",`نورّت يا ${currentUser.name.split(" ")[0]}.`);
  });

  document.getElementById("registerForm").addEventListener("submit",e=>{
    e.preventDefault();
    const name=document.getElementById("registerName").value.trim();
    const identifier=document.getElementById("registerIdentifier").value.trim().toLowerCase();
    const pass=document.getElementById("registerPassword").value;
    const confirm=document.getElementById("registerConfirm").value;
    if(pass.length<6){toast("تنبيه","كلمة المرور لازم تكون 6 أحرف على الأقل.");return}
    if(pass!==confirm){toast("تنبيه","تأكيد كلمة المرور غير مطابق.");return}
    if(db.users.some(u=>u.identifier.toLowerCase()===identifier)){toast("تنبيه","الحساب موجود بالفعل.");return}
    const u={id:uid(),name,identifier,password:pass,year:document.getElementById("registerYear").value.trim()||"ثانية بكالوريا",semester:document.getElementById("registerSemester").value,track:document.getElementById("registerTrack").value.trim()||"الهندسة وعلوم الحاسب",completed:[],notifications:[],avatar:defaultAvatar(name),lastActive:Date.now(),settings:{theme:"light",language:"auto",sound:"on",quranUrl:""}};
    db.users.push(u);saveDB();currentUser=u;currentUserId=u.id;localStorage.setItem(SESSION_KEY,u.id);enterApp();
    toast("تم إنشاء الحساب","ابدأ بأول محاضرة وخلي التقدم يتكلم عنك.");
  });

  document.getElementById("logoutBtn").addEventListener("click",()=>{
    localStorage.removeItem(SESSION_KEY);currentUser=null;document.getElementById("appShell").classList.add("hidden");document.getElementById("authScreen").classList.remove("hidden");
  });
  document.getElementById("menuBtn").addEventListener("click",()=>document.getElementById("sidebar").classList.toggle("open"));
  document.getElementById("themeBtn").addEventListener("click",()=>{
    currentUser.settings.theme=currentUser.settings.theme==="dark"?"light":"dark";saveDB();applyTheme();markActivity();
  });
  document.getElementById("notificationsBtn").addEventListener("click",()=>{
    currentUser.notifications.forEach(n=>n.read=true);saveDB();renderNotifications();updateBadge();openModal("notificationsModal");
  });
  document.getElementById("settingsBtn").addEventListener("click",()=>{renderSettings();openModal("settingsModal")});
  document.getElementById("profileBtn").addEventListener("click",()=>{renderProfile();openModal("profileModal")});
  document.getElementById("profileSettingsBtn").addEventListener("click",()=>{closeModal("profileModal");openModal("settingsModal")});
  document.getElementById("clearNotifications").addEventListener("click",()=>{currentUser.notifications=[];saveDB();renderNotifications();updateBadge()});
  document.querySelectorAll("[data-close-modal]").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.closeModal)));
  document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.add("hidden")}));

  document.querySelectorAll("[data-section], [data-section-link]").forEach(b=>b.addEventListener("click",()=>showSection(b.dataset.section||b.dataset.sectionLink)));
  document.getElementById("teacherFilter").addEventListener("change",renderLectures);
  document.getElementById("statusFilter").addEventListener("change",renderLectures);
  document.addEventListener("click",e=>{
    const btn=e.target.closest("[data-complete-id]");
    if(btn)completeLecture(btn.dataset.completeId);
  });

  document.querySelectorAll("[data-minutes]").forEach(b=>b.addEventListener("click",()=>setTimerMinutes(Number(b.dataset.minutes))));
  document.getElementById("customTimerBtn").addEventListener("click",()=>{
    const min=Number(prompt(getLanguage()==="ar"?"اكتب عدد الدقائق:":"Enter minutes:","30"));
    if(Number.isFinite(min)&&min>0&&min<=600)setTimerMinutes(min);
  });
  document.getElementById("startTimer").addEventListener("click",startTimer);
  document.getElementById("pauseTimer").addEventListener("click",pauseTimer);
  document.getElementById("resetTimer").addEventListener("click",resetTimer);
  document.getElementById("playQuran").addEventListener("click",()=>{const a=document.getElementById("quranAudio");if(!a.src){toast("تنبيه",getLanguage()==="ar"?"أضف رابط الصوت من الإعدادات أولاً.":"Add the audio URL in settings first.");return}a.play().catch(()=>{});});
  document.getElementById("stopQuran").addEventListener("click",()=>{const a=document.getElementById("quranAudio");a.pause();a.currentTime=0});

  document.getElementById("quranSourceBtn").addEventListener("click",()=>window.open("https://tanzil.net/","_blank","noopener"));
  document.getElementById("azkarBtn").addEventListener("click",()=>showContent(t("morningEvening"),`<ul><li>سبحان الله وبحمده.</li><li>أستغفر الله.</li><li>لا إله إلا الله وحده لا شريك له.</li><li>الصلاة على النبي ﷺ.</li></ul><p>يمكنك الرجوع إلى كتاب أو مصدر موثوق للأذكار للتأكد من النصوص الكاملة.</p>`));
  document.getElementById("duasBtn").addEventListener("click",()=>showContent(t("studyDuas"),`<ul><li>رب زدني علمًا.</li><li>اللهم انفعني بما علمتني وعلمني ما ينفعني.</li><li>اللهم يسر لي أمري ووفقني لما فيه الخير.</li></ul>`));
  document.getElementById("actsBtn").addEventListener("click",()=>showContent(t("otherActs"),`<ul><li>المحافظة على الصلاة.</li><li>بر الوالدين.</li><li>الصدقة ولو بالقليل.</li><li>الذكر والاستغفار.</li><li>مساعدة الآخرين.</li></ul>`));

  document.getElementById("saveSettings").addEventListener("click",()=>{
    currentUser.settings.language=document.getElementById("languageSelect").value;
    currentUser.settings.sound=document.getElementById("soundSelect").value;
    currentUser.settings.quranUrl=document.getElementById("quranUrlInput").value.trim();
    saveDB();applyLanguage();closeModal("settingsModal");toast("تم","تم حفظ الإعدادات.");
  });
  document.getElementById("avatarInput").addEventListener("change",e=>{
    const file=e.target.files?.[0];if(!file)return;
    if(file.size>2*1024*1024){toast("تنبيه","اختار صورة أقل من 2MB.");return}
    const reader=new FileReader();reader.onload=()=>{currentUser.avatar=reader.result;saveDB();renderAll();toast("تم","تم تغيير صورة الحساب.")};reader.readAsDataURL(file);
  });
}

function enterApp(){
  document.getElementById("authScreen").classList.add("hidden");
  document.getElementById("appShell").classList.remove("hidden");
  currentUser=ensureUserShape(currentUser);markActivity();dailyScheduleNotifications();applyLanguage();setTimerMinutes(25);
}
function init(){
  setupEvents();
  if(currentUser){currentUser=ensureUserShape(currentUser);enterApp()}
  else document.getElementById("authScreen").classList.remove("hidden");
}
setInterval(()=>{if(currentUser){markActivity();document.getElementById("activityText")&&(document.getElementById("activityText").textContent=activityLabel())}},60000);
init();
})();